var appData = {
	name: 'Gmail',
	mailboxes: [
		'inbox',
		'starred',
        'sent',
        'important',
        'promotions',
        'draft',
	],
	contacts: [
		{name: 'Stephanie', lastMessage: "I'm open on Friday"},
		{name: 'Grandpa', lastMessage: "Make $10,000 Online With This One Weird Trick!"}
	]

}

console.log(appData.mailboxes)